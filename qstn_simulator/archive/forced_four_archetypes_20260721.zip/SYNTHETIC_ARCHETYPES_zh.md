# Synthetic Archetype Persona 设计

## 定位

这四类 persona 是为了构造可控的长期类人反馈源，由研究者明确设计，不是从 201 位参与者的标签拟合得到，也不能作为真人群体比例或心理类型的经验结论。

现有 `personas.csv` 继续作为 **201 个 profile-conditioned 校准实例**；新文件 `synthetic_archetypes.csv` 才是后续状态 wrapper 和 RL 环境使用的稳定 archetype。

## 四类机制

| Archetype | 主导机制 | 与其他类型的区别 |
| --- | --- | --- |
| Privacy-Sensitive | 数据敏感度、用途限制、接收方边界 | 即使 agent 可靠，也不愿扩大敏感数据的用途和持久授权。 |
| Convenience-First | 降低确认次数和任务摩擦 | 对熟悉工具和必要数据更愿意持续授权，但不应无条件允许高敏感或不必要访问。 |
| Technically Skilled | 最小权限、目的匹配、接收方和授权时长 | 不是单纯更愿意分享；它会更精细地区分必要访问和权限扩大。 |
| Risk-Averse | 不确定性、不可逆后果、近期错误 | 不只关注“隐私数据”，而是对不确定结果和错误历史产生最强的信任下降。 |

## 参数解释

所有数值参数都在 `[0, 1]`，目前是可检查的设计假设，不是学习结果。

- `privacy_conservatism`：总体隐私保守程度。
- `convenience_preference`：减少询问和操作摩擦的重要性。
- `technical_literacy`：识别必要性、接收方、时长和最小化范围的能力。
- `risk_aversion`：对不确定和不可逆损害的厌恶。
- `initial_trust`：长期交互开始时对 agent 的初始信任。
- `persistent_access_aversion`：对 `always share` 类持久权限的抗拒。
- `minimization_preference`：对最小化披露的偏好。
- `interruption_cost`：被反复询问造成的成本。
- `fatigue_sensitivity`：随着询问次数增加而产生疲劳的速度。
- `negative_update_rate`：agent 越权或犯错后信任下降速度。
- `positive_recovery_rate`：连续安全行为后信任恢复速度。
- `domain_sensitivity`：对八个 permission domain 的相对敏感度。

## 当前阶段如何使用

QSTN 当前只使用 `system_prompt` 和 `questionnaire_instruction` 生成静态四标签回答。数值参数先作为未来 wrapper 的稳定初值保存，尚未参与状态转移。

下一阶段的 wrapper 应当维护 `trust_level`、`fatigue`、`mistake_history` 和 `recent_overreach`，并用 `negative_update_rate`、`positive_recovery_rate` 等参数更新状态。届时，同一 archetype 才会因为不同交互历史产生不同回答。

## 研究边界

1. 不将四类称为真实人口中的自然心理分类。
2. 不使用 human Task 3 标签直接编写某一 archetype 的回答规则。
3. 先检查四类是否产生可区分但非退化的回答分布，例如不能全部只回答 `No, never share`。
4. 将参数敏感性分析作为后续实验的一部分，避免结论依赖单组手工数值。
