# Task Plan: QSTN Permission Simulator Setup

## Goal
Create a reproducible, isolated QSTN environment for the permission-response simulator without changing the existing four-label benchmark.

## Phases
- [x] Phase 1: Inspect the existing benchmark, data schema, and Python runtime.
- [x] Phase 2: Add isolated QSTN project configuration and documentation.
- [x] Phase 3: Create the environment and install locked dependencies.
- [x] Phase 4: Run installation and dataset-access smoke tests.
- [x] Phase 5: Convert permission contexts into QSTN questionnaire items and profile-grounded personas.
- [x] Phase 6: Verify one live OpenAI-backed QSTN response.
- [x] Phase 7: Design and validate four synthetic archetype personas.

## Decisions Made
- Use a nested `qstn_simulator` project so its QSTN dependencies do not alter the benchmark `.venv`.
- Use Python 3.12 because QSTN requires Python 3.12 or newer.
- Read the existing processed four-label CSV as a calibration source; do not modify it.

## Errors Encountered
- `ai_agent_permission_experiment` is not an independent Git repository; configuration will be verified through file and runtime checks instead.
- The restricted shell cannot use uv's global cache; `uv sync` was completed with approved access, and direct `.venv` execution avoids this issue for local checks.
- A parallel validation attempted to read `calibration_assignments.csv` before the generator completed; rerun generation and validation sequentially.

## Status
Complete. The 201-person calibration baseline remains unchanged. Four hand-designed synthetic archetypes were generated from a versioned config and validated as 4 QSTN surveys with 373 items each; no LLM API call was made for this phase.
