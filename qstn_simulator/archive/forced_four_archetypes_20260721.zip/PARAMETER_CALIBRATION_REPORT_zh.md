# Parameter Calibration Report

## Scope

The archetype meanings and names are researcher-defined. The raw human data have no archetype labels, so this analysis estimates participant-level static traits, learns four exploratory clusters, and matches those clusters one-to-one to the hand-specified prototypes.

Raw lineage: `external/ai-agent-permissions/data/user_study.json` -> `data/processed/four_label_dataset.csv` -> participant-level estimates.

## Estimators

- `privacy_conservatism`: mean of normalized self-reported privacy importance and restrictiveness on nonnecessary requests.
- `convenience_preference`: mean of AI-use frequency, AI trust, and persistent-grant preference on necessary requests.
- `technical_literacy`: mean of AI familiarity, AI-use frequency, and discrimination between necessary and nonnecessary requests.
- `risk_aversion`: mean of inverse AI trust, never-share rate, and restrictiveness on nonnecessary requests.
- `initial_trust`: normalized self-reported AI trust.
- `persistent_access_aversion`: one minus the participant's always-share rate.
- `interruption_cost`: persistent grants divided by positive grants on necessary requests.
- `domain_sensitivity`: one minus the normalized mean permission label in each domain.

These are proxy estimators, not validated psychological scales.

## Validation

- Participants: 201 (160 train, 41 held out).
- Train/test silhouette: 0.196 / 0.187.
- Mean seed stability (adjusted Rand index): 0.985.
- Held-out trait-centroid MAE: 0.079.

The high seed stability means the partition is computationally reproducible. The low silhouette means the four groups overlap substantially and should be described as exploratory regions in a continuous preference space, not natural human types.

## Hand-Specified Versus Learned

| Archetype | N train/test | Privacy H/L | Convenience H/L | Technical H/L | Risk H/L | Trust H/L | Persistent aversion H/L | Interruption cost H/L |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Convenience-First | 42/13 | 0.300/0.621 | 0.900/0.630 | 0.450/0.689 | 0.250/0.389 | 0.750/0.488 | 0.250/0.329 | 0.900/0.771 |
| Privacy-Sensitive | 15/2 | 0.900/0.723 | 0.250/0.511 | 0.550/0.586 | 0.750/0.594 | 0.350/0.450 | 0.900/0.858 | 0.200/0.432 |
| Risk-Averse | 51/13 | 0.750/0.660 | 0.250/0.244 | 0.450/0.482 | 0.950/0.525 | 0.250/0.240 | 0.850/0.870 | 0.250/0.164 |
| Technically Skilled | 52/13 | 0.650/0.630 | 0.550/0.563 | 0.950/0.712 | 0.550/0.322 | 0.550/0.567 | 0.700/0.735 | 0.450/0.346 |

`H/L` means hand-specified / learned from the training participants.

## Not Identifiable

The current study has no minimize option and no longitudinal sequence of agent mistakes, repeated prompts, trust decay, or recovery. Therefore the following parameters are not learned:

- `minimization_preference`
- `fatigue_sensitivity`
- `negative_update_rate`
- `positive_recovery_rate`

Their calibrated JSON values are `null`; hand-specified values are retained only as explicitly marked fallbacks.

## Interpretation Boundary

This run supports using human-calibrated static priors as an experimental alternative to hand-specified priors. It does not establish population prevalence, validate the archetype names as psychological constructs, or estimate longitudinal state-transition parameters.
