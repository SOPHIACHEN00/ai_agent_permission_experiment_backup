# QSTN Permission Simulator

This isolated project prepares QSTN as the questionnaire-response layer for the AI-agent permission study. It intentionally leaves the parent four-label benchmark unchanged.

## Why it is separate

The parent project predicts answers observed in a static user study. This project will generate simulated questionnaire responses, then calibrate them against that study before any reinforcement-learning experiment uses them.

## Setup

From this directory:

```powershell
uv sync
Copy-Item .env.example .env
# Add OPENAI_API_KEY to .env locally.
uv run python scripts/check_environment.py
```

The smoke test does not call an LLM or transmit data. It verifies QSTN, the local environment, and read-only access to the four-label dataset.

## Build QSTN Inputs

```powershell
.\.venv\Scripts\python.exe scripts\build_qstn_inputs.py
```

This creates `outputs/questionnaire_items.csv`, `outputs/personas.csv`, and `outputs/calibration_assignments.csv` locally. The questionnaire has one closed-ended permission item per observed request/tool/data context. Personas use only structured, anonymized profile fields; the observed Task 3 answers are excluded to prevent label leakage.

`calibration_assignments.csv` is the evaluation index: it contains only persona-question pairs with an observed human Task 3 label. Do not treat unobserved combinations in the full 201-by-373 simulation space as human ground truth.

Read `PERSONA_DESIGN_zh.md` before making any external LLM call with the generated personas.

## One-Question API Smoke Test

After setting `OPENAI_API_KEY` in `.env`, run:

```powershell
.\.venv\Scripts\python.exe scripts\smoke_test_openai_qstn.py
```

This sends one persona and one permission item to the configured OpenAI model. It writes the validated four-option response to `outputs/openai_qstn_smoke_test.json`.

## Synthetic Archetypes

Build the four hand-designed, wrapper-ready archetypes separately from the 201-person calibration baseline:

```powershell
.\.venv\Scripts\python.exe scripts\build_synthetic_archetypes.py
```

The source of truth is `config/synthetic_archetypes.json`; the QSTN-ready output is `outputs/synthetic_archetypes.csv`. These are controlled research hypotheses, not archetypes learned from human labels. See `SYNTHETIC_ARCHETYPES_zh.md` for the behavioral distinctions and parameter definitions.

### Human-data calibration

Estimate the identifiable static parameters from the raw-derived four-label human data:

```powershell
.\.venv\Scripts\python.exe scripts\calibrate_archetypes_from_human_data.py
```

The hand-specified parameter set remains `hand_specified_v1` in `config/synthetic_archetypes.json`. The script writes the separate `raw_human_calibrated_v1` artifacts:

- `outputs/participant_trait_estimates.csv`
- `outputs/learned_archetype_assignments.csv`
- `outputs/learned_archetypes.json`
- `outputs/synthetic_archetypes_calibrated.csv`
- `outputs/PARAMETER_CALIBRATION_REPORT_zh.md`

The raw study has no archetype labels. Cluster names are matched to the hand-specified prototypes, so this is exploratory calibration rather than discovery of natural psychological types. Static proxies and domain sensitivity are estimated from data; minimization, fatigue, negative trust update, and positive recovery remain explicitly marked as not identifiable from the current cross-sectional study.

For a Chinese recap of the distinction between data-driven persona discovery and theory-driven archetype calibration, including the exploratory `k=2..8` comparison, see `PERSONA_DISCOVERY_AND_CALIBRATION_RECAP_zh.md`.

## Next integration step

Convert selected permission rows into a QSTN questionnaire and define a small, documented persona set. Keep the human-study labels as the calibration target, not as generated data.
