"""Estimate static archetype parameters from raw-derived human permission data."""

from __future__ import annotations

import argparse
import itertools
import json
import os
from pathlib import Path
from typing import Any

os.environ.setdefault("LOKY_MAX_CPU_COUNT", "1")

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA = PROJECT_ROOT.parent / "data" / "processed" / "four_label_dataset.csv"
DEFAULT_CONFIG = PROJECT_ROOT / "config" / "synthetic_archetypes.json"
DEFAULT_TRAITS_OUT = PROJECT_ROOT / "outputs" / "participant_trait_estimates.csv"
DEFAULT_ASSIGNMENTS_OUT = PROJECT_ROOT / "outputs" / "learned_archetype_assignments.csv"
DEFAULT_CONFIG_OUT = PROJECT_ROOT / "outputs" / "learned_archetypes.json"
DEFAULT_CSV_OUT = PROJECT_ROOT / "outputs" / "synthetic_archetypes_calibrated.csv"
DEFAULT_REPORT_OUT = PROJECT_ROOT / "outputs" / "PARAMETER_CALIBRATION_REPORT_zh.md"

LEARNED_TRAITS = [
    "privacy_conservatism",
    "convenience_preference",
    "technical_literacy",
    "risk_aversion",
    "initial_trust",
    "persistent_access_aversion",
    "interruption_cost",
]
NOT_IDENTIFIABLE = [
    "minimization_preference",
    "fatigue_sensitivity",
    "negative_update_rate",
    "positive_recovery_rate",
]
CLUSTER_FEATURES = [
    "privacy_importance_norm",
    "ai_familiarity_norm",
    "ai_frequency_norm",
    "ai_trust_norm",
    "always_share_rate",
    "never_share_rate",
    "ask_rate",
    "necessary_share_score",
    "nonnecessary_share_score",
    "necessity_discrimination",
]
MATCH_TRAITS = [
    "privacy_conservatism",
    "convenience_preference",
    "technical_literacy",
    "risk_aversion",
]


def unit_profile(value: Any) -> float:
    numeric = float(value)
    if not 1.0 <= numeric <= 5.0:
        raise ValueError(f"Expected a 1..5 profile response, got {value!r}.")
    return (numeric - 1.0) / 4.0


def mean_or(series: pd.Series, fallback: float) -> float:
    return float(series.mean()) if not series.empty else fallback


def build_participant_traits(data: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for participant_id, group in data.groupby("participant_id", sort=True):
        label = group["label_id"].astype(float)
        share = label / 3.0
        necessary = group["necessity_status"].eq("necessary")
        nonnecessary = ~necessary
        positive_necessary = necessary & group["label_id"].isin([2, 3])

        privacy_profile = unit_profile(group["privacy_importance"].iloc[0])
        familiarity = unit_profile(group["ai_familiarity"].iloc[0])
        frequency = unit_profile(group["ai_frequency"].iloc[0])
        trust = unit_profile(group["ai_trust"].iloc[0])
        necessary_share = mean_or(share[necessary], float(share.mean()))
        nonnecessary_share = mean_or(share[nonnecessary], float(share.mean()))
        nonnecessary_restrictiveness = 1.0 - nonnecessary_share
        discrimination = np.clip((necessary_share - nonnecessary_share + 1.0) / 2.0, 0.0, 1.0)
        positive_persistence = mean_or(
            group.loc[positive_necessary, "label_id"].eq(3).astype(float), 0.5
        )
        always_rate = float(group["label_id"].eq(3).mean())
        never_rate = float(group["label_id"].eq(0).mean())
        ask_rate = float(group["label_id"].isin([1, 2]).mean())

        rows.append(
            {
                "participant_id": participant_id,
                "n_responses": int(len(group)),
                "privacy_importance_norm": privacy_profile,
                "ai_familiarity_norm": familiarity,
                "ai_frequency_norm": frequency,
                "ai_trust_norm": trust,
                "always_share_rate": always_rate,
                "never_share_rate": never_rate,
                "ask_rate": ask_rate,
                "necessary_share_score": necessary_share,
                "nonnecessary_share_score": nonnecessary_share,
                "necessity_discrimination": float(discrimination),
                "privacy_conservatism": float(
                    np.mean([privacy_profile, nonnecessary_restrictiveness])
                ),
                "convenience_preference": float(
                    np.mean([frequency, trust, positive_persistence])
                ),
                "technical_literacy": float(
                    np.mean([familiarity, frequency, discrimination])
                ),
                "risk_aversion": float(
                    np.mean([1.0 - trust, never_rate, nonnecessary_restrictiveness])
                ),
                "initial_trust": trust,
                "persistent_access_aversion": 1.0 - always_rate,
                "interruption_cost": positive_persistence,
            }
        )
    return pd.DataFrame(rows)


def match_clusters_to_archetypes(
    train_traits: pd.DataFrame,
    hand_config: dict[str, Any],
) -> tuple[dict[int, str], float]:
    cluster_ids = sorted(int(value) for value in train_traits["cluster_id"].unique())
    archetypes = hand_config["archetypes"]
    archetype_ids = [item["archetype_id"] for item in archetypes]
    hand_vectors = {
        item["archetype_id"]: np.array([item["traits"][name] for name in MATCH_TRAITS])
        for item in archetypes
    }
    cluster_vectors = {
        cluster_id: train_traits.loc[
            train_traits["cluster_id"].eq(cluster_id), MATCH_TRAITS
        ].mean().to_numpy()
        for cluster_id in cluster_ids
    }

    best_mapping: dict[int, str] | None = None
    best_distance = float("inf")
    for permutation in itertools.permutations(archetype_ids):
        mapping = dict(zip(cluster_ids, permutation, strict=True))
        distance = sum(
            float(np.square(cluster_vectors[cluster_id] - hand_vectors[archetype_id]).sum())
            for cluster_id, archetype_id in mapping.items()
        )
        if distance < best_distance:
            best_distance = distance
            best_mapping = mapping
    if best_mapping is None:
        raise RuntimeError("Could not match learned clusters to archetypes.")
    return best_mapping, best_distance


def parameter_entry(value: float, estimator: str) -> dict[str, Any]:
    return {
        "value": round(float(value), 6),
        "source": "estimated_from_raw_human_data",
        "estimator": estimator,
    }


def build_learned_outputs(
    data: pd.DataFrame,
    traits: pd.DataFrame,
    hand_config: dict[str, Any],
    mapping: dict[int, str],
    metrics: dict[str, Any],
) -> tuple[dict[str, Any], pd.DataFrame]:
    hand_lookup = {item["archetype_id"]: item for item in hand_config["archetypes"]}
    learned_archetypes: list[dict[str, Any]] = []
    flat_rows: list[dict[str, Any]] = []

    for cluster_id, archetype_id in sorted(mapping.items(), key=lambda item: item[1]):
        hand = hand_lookup[archetype_id]
        train_members = traits.loc[
            traits["split"].eq("train") & traits["cluster_id"].eq(cluster_id)
        ]
        test_members = traits.loc[
            traits["split"].eq("test") & traits["cluster_id"].eq(cluster_id)
        ]
        train_ids = set(train_members["participant_id"])
        domain_values = (
            data.loc[data["participant_id"].isin(train_ids)]
            .assign(sensitivity=lambda frame: 1.0 - frame["label_id"].astype(float) / 3.0)
            .groupby("domain")["sensitivity"]
            .mean()
            .reindex(hand_config["domains"])
        )

        learned_traits = {
            name: parameter_entry(
                train_members[name].mean(),
                f"mean participant-level {name} within the matched training cluster",
            )
            for name in LEARNED_TRAITS
        }
        for name in NOT_IDENTIFIABLE:
            learned_traits[name] = {
                "value": None,
                "source": "not_identifiable_from_current_cross_sectional_data",
                "hand_specified_fallback": hand["traits"][name],
            }

        domain_sensitivity = {
            domain: parameter_entry(
                value,
                "one minus mean normalized permission label within the matched training cluster",
            )
            for domain, value in domain_values.items()
        }
        learned_archetypes.append(
            {
                "archetype_id": archetype_id,
                "display_name": hand["display_name"],
                "matched_cluster_id": cluster_id,
                "n_train_participants": int(len(train_members)),
                "n_test_participants": int(len(test_members)),
                "traits": learned_traits,
                "domain_sensitivity": domain_sensitivity,
                "hand_specified_reference": hand["traits"],
            }
        )

        flat: dict[str, Any] = {
            "archetype_id": archetype_id,
            "display_name": hand["display_name"],
            "parameter_set_id": "raw_human_calibrated_v1",
            "n_train_participants": int(len(train_members)),
            "n_test_participants": int(len(test_members)),
        }
        for name, entry in learned_traits.items():
            flat[name] = entry["value"] if entry["value"] is not None else entry["hand_specified_fallback"]
            flat[f"{name}_source"] = entry["source"]
        flat["domain_sensitivity_json"] = json.dumps(
            {domain: entry["value"] for domain, entry in domain_sensitivity.items()},
            ensure_ascii=False,
            sort_keys=True,
        )
        flat_rows.append(flat)

    learned_config = {
        "calibration_version": "1.0",
        "parameter_set_id": "raw_human_calibrated_v1",
        "source_dataset": str(DEFAULT_DATA.relative_to(PROJECT_ROOT.parent)),
        "status": "exploratory_data_calibration_not_population_typology",
        "method": {
            "participant_split": "80% train / 20% held-out test, random_state=42",
            "clustering": "StandardScaler plus KMeans(k=4, n_init=50) on participant-level profile and permission summaries",
            "cluster_naming": "minimum-distance one-to-one matching to hand-specified archetype prototypes",
            "warning": "Archetype names remain researcher-defined; only cluster centers and identifiable static parameters are estimated from data.",
        },
        "identifiability": {
            "estimated_static_traits": LEARNED_TRAITS,
            "estimated_contextual_parameters": ["domain_sensitivity"],
            "not_identifiable_from_current_data": NOT_IDENTIFIABLE,
        },
        "metrics": metrics,
        "archetypes": learned_archetypes,
    }
    return learned_config, pd.DataFrame(flat_rows)


def write_report(
    path: Path,
    learned_config: dict[str, Any],
    calibrated_csv: pd.DataFrame,
    hand_config: dict[str, Any],
) -> None:
    hand_lookup = {item["archetype_id"]: item for item in hand_config["archetypes"]}
    metrics = learned_config["metrics"]
    lines = [
        "# Parameter Calibration Report",
        "",
        "## Scope",
        "",
        "The archetype meanings and names are researcher-defined. The raw human data have no archetype labels, so this analysis estimates participant-level static traits, learns four exploratory clusters, and matches those clusters one-to-one to the hand-specified prototypes.",
        "",
        "Raw lineage: `external/ai-agent-permissions/data/user_study.json` -> `data/processed/four_label_dataset.csv` -> participant-level estimates.",
        "",
        "## Estimators",
        "",
        "- `privacy_conservatism`: mean of normalized self-reported privacy importance and restrictiveness on nonnecessary requests.",
        "- `convenience_preference`: mean of AI-use frequency, AI trust, and persistent-grant preference on necessary requests.",
        "- `technical_literacy`: mean of AI familiarity, AI-use frequency, and discrimination between necessary and nonnecessary requests.",
        "- `risk_aversion`: mean of inverse AI trust, never-share rate, and restrictiveness on nonnecessary requests.",
        "- `initial_trust`: normalized self-reported AI trust.",
        "- `persistent_access_aversion`: one minus the participant's always-share rate.",
        "- `interruption_cost`: persistent grants divided by positive grants on necessary requests.",
        "- `domain_sensitivity`: one minus the normalized mean permission label in each domain.",
        "",
        "These are proxy estimators, not validated psychological scales.",
        "",
        "## Validation",
        "",
        f"- Participants: {metrics['n_participants']} ({metrics['n_train_participants']} train, {metrics['n_test_participants']} held out).",
        f"- Train/test silhouette: {metrics['train_silhouette']:.3f} / {metrics['test_silhouette']:.3f}.",
        f"- Mean seed stability (adjusted Rand index): {metrics['mean_seed_adjusted_rand_index']:.3f}.",
        f"- Held-out trait-centroid MAE: {metrics['heldout_trait_centroid_mae']:.3f}.",
        "",
        "The high seed stability means the partition is computationally reproducible. The low silhouette means the four groups overlap substantially and should be described as exploratory regions in a continuous preference space, not natural human types.",
        "",
        "## Hand-Specified Versus Learned",
        "",
        "| Archetype | N train/test | Privacy H/L | Convenience H/L | Technical H/L | Risk H/L | Trust H/L | Persistent aversion H/L | Interruption cost H/L |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for row in calibrated_csv.sort_values("archetype_id").itertuples(index=False):
        hand = hand_lookup[row.archetype_id]["traits"]
        pair = lambda name: f"{hand[name]:.3f}/{getattr(row, name):.3f}"
        lines.append(
            "| "
            + " | ".join(
                [
                    row.display_name,
                    f"{row.n_train_participants}/{row.n_test_participants}",
                    pair("privacy_conservatism"),
                    pair("convenience_preference"),
                    pair("technical_literacy"),
                    pair("risk_aversion"),
                    pair("initial_trust"),
                    pair("persistent_access_aversion"),
                    pair("interruption_cost"),
                ]
            )
            + " |"
        )
    lines.extend(
        [
            "",
            "`H/L` means hand-specified / learned from the training participants.",
            "",
            "## Not Identifiable",
            "",
            "The current study has no minimize option and no longitudinal sequence of agent mistakes, repeated prompts, trust decay, or recovery. Therefore the following parameters are not learned:",
            "",
            "- `minimization_preference`",
            "- `fatigue_sensitivity`",
            "- `negative_update_rate`",
            "- `positive_recovery_rate`",
            "",
            "Their calibrated JSON values are `null`; hand-specified values are retained only as explicitly marked fallbacks.",
            "",
            "## Interpretation Boundary",
            "",
            "This run supports using human-calibrated static priors as an experimental alternative to hand-specified priors. It does not establish population prevalence, validate the archetype names as psychological constructs, or estimate longitudinal state-transition parameters.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--hand-config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--traits-out", type=Path, default=DEFAULT_TRAITS_OUT)
    parser.add_argument("--assignments-out", type=Path, default=DEFAULT_ASSIGNMENTS_OUT)
    parser.add_argument("--config-out", type=Path, default=DEFAULT_CONFIG_OUT)
    parser.add_argument("--csv-out", type=Path, default=DEFAULT_CSV_OUT)
    parser.add_argument("--report-out", type=Path, default=DEFAULT_REPORT_OUT)
    args = parser.parse_args()

    data = pd.read_csv(args.data)
    with args.hand_config.open(encoding="utf-8") as handle:
        hand_config = json.load(handle)
    traits = build_participant_traits(data)

    train_ids, test_ids = train_test_split(
        traits["participant_id"].to_numpy(), test_size=0.2, random_state=42
    )
    traits["split"] = np.where(traits["participant_id"].isin(train_ids), "train", "test")
    train_mask = traits["split"].eq("train")
    scaler = StandardScaler()
    train_x = scaler.fit_transform(traits.loc[train_mask, CLUSTER_FEATURES])
    test_x = scaler.transform(traits.loc[~train_mask, CLUSTER_FEATURES])
    model = KMeans(n_clusters=4, n_init=50, random_state=42)
    traits.loc[train_mask, "cluster_id"] = model.fit_predict(train_x)
    traits.loc[~train_mask, "cluster_id"] = model.predict(test_x)
    traits["cluster_id"] = traits["cluster_id"].astype(int)

    train_traits = traits.loc[train_mask]
    mapping, mapping_distance = match_clusters_to_archetypes(train_traits, hand_config)
    traits["archetype_id"] = traits["cluster_id"].map(mapping)

    reference_labels = model.labels_
    stability_scores = []
    for seed in range(20):
        repeated = KMeans(n_clusters=4, n_init=20, random_state=seed).fit_predict(train_x)
        stability_scores.append(adjusted_rand_score(reference_labels, repeated))

    train_centroids = train_traits.groupby("cluster_id")[LEARNED_TRAITS].mean()
    test_centroids = traits.loc[~train_mask].groupby("cluster_id")[LEARNED_TRAITS].mean()
    common_clusters = train_centroids.index.intersection(test_centroids.index)
    heldout_mae = float(
        np.abs(train_centroids.loc[common_clusters] - test_centroids.loc[common_clusters])
        .to_numpy()
        .mean()
    )
    metrics = {
        "n_participants": int(len(traits)),
        "n_train_participants": int(train_mask.sum()),
        "n_test_participants": int((~train_mask).sum()),
        "train_silhouette": round(float(silhouette_score(train_x, model.labels_)), 6),
        "test_silhouette": round(
            float(silhouette_score(test_x, traits.loc[~train_mask, "cluster_id"])), 6
        ),
        "mean_seed_adjusted_rand_index": round(float(np.mean(stability_scores)), 6),
        "heldout_trait_centroid_mae": round(heldout_mae, 6),
        "prototype_mapping_squared_distance": round(mapping_distance, 6),
    }
    learned_config, calibrated_csv = build_learned_outputs(
        data, traits, hand_config, mapping, metrics
    )

    for path in [
        args.traits_out,
        args.assignments_out,
        args.config_out,
        args.csv_out,
        args.report_out,
    ]:
        path.parent.mkdir(parents=True, exist_ok=True)
    traits.to_csv(args.traits_out, index=False, encoding="utf-8")
    traits[["participant_id", "split", "cluster_id", "archetype_id"]].to_csv(
        args.assignments_out, index=False, encoding="utf-8"
    )
    args.config_out.write_text(
        json.dumps(learned_config, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    calibrated_csv.to_csv(args.csv_out, index=False, encoding="utf-8")
    write_report(args.report_out, learned_config, calibrated_csv, hand_config)
    print(json.dumps(metrics, indent=2))
    print(f"Wrote learned calibration for {len(calibrated_csv)} archetypes.")


if __name__ == "__main__":
    main()
