# Persona Discovery and Calibration Recap

## 1. 核心结论

当前项目需要严格区分两件事：

1. **Data-driven persona discovery**：让 201 位真人参与者的数据决定存在几类行为群体，以及每类的经验参数。
2. **Theory-driven archetype calibration**：研究者先定义 persona 的含义，再用真人数据校准其中可观测的静态参数。

当前的 `Privacy-Sensitive`、`Convenience-First`、`Technically Skilled` 和 `Risk-Averse` 属于第二类。它们的名称、构念和四类数量由研究设计给出，不是 raw data 自动发现的自然人群类型。

更准确的论文表述是：

> The four theory-driven archetypes are researcher-defined prototypes in a shared permission-preference space. Their identifiable static parameters can be calibrated against observed human responses, but the archetypes themselves are not discovered population types.

## 2. 数据来源

数据链路为：

```text
external/ai-agent-permissions/data/user_study.json
    -> data/processed/four_label_dataset.csv
    -> participant-level observable summaries
    -> clustering or archetype calibration
```

- `user_study.json`：203 位匿名参与者的原始调查数据。
- 当前分析仅保留 `Valid == True` 的 201 位参与者。
- `four_label_dataset.csv`：将 Task 3 展开为一行一个 permission decision，共 16,361 行。
- 每位参与者有约 63--91 条有效 permission decisions。

四个标签映射为：

| Label ID | Human response | Normalized share score |
| ---: | --- | ---: |
| 0 | No, never share | 0.000 |
| 1 | No, but ask me next time | 0.333 |
| 2 | Yes, but ask me next time | 0.667 |
| 3 | Yes, always share | 1.000 |

## 3. Participant-level observable summaries

每位参与者首先被表示成一个十维可观测向量：

```text
privacy_importance_norm
ai_familiarity_norm
ai_frequency_norm
ai_trust_norm
always_share_rate
never_share_rate
ask_rate
necessary_share_score
nonnecessary_share_score
necessity_discrimination
```

1--5 分的 profile 字段通过以下公式归一化：

```text
normalized_value = (raw_value - 1) / 4
```

主要行为统计量为：

```text
always_share_rate = count(label == 3) / all responses
never_share_rate  = count(label == 0) / all responses
ask_rate          = count(label in {1, 2}) / all responses

necessary_share_score
    = mean(label_id / 3 | necessity_status == necessary)

nonnecessary_share_score
    = mean(label_id / 3 | necessity_status != necessary)

necessity_discrimination
    = (necessary_share_score - nonnecessary_share_score + 1) / 2
```

注意：当前 `nonnecessary` 合并了 `incorrect_explicit` 和 `unknown`。正式实验应将二者分开，并进行敏感性分析，因为 `unknown` 不一定等于真正不必要。

## 4. 当前 hand-specified trait proxies

当前校准脚本还将可观测量组合为以下 trait proxies：

```text
privacy_conservatism
    = mean(privacy importance,
           restrictiveness on nonnecessary requests)

convenience_preference
    = mean(AI-use frequency,
           AI trust,
           persistent-grant preference on necessary requests)

technical_literacy
    = mean(AI familiarity,
           AI-use frequency,
           necessity discrimination)

risk_aversion
    = mean(inverse AI trust,
           never-share rate,
           restrictiveness on nonnecessary requests)
```

这些 trait 的输入来自真人数据，但组合公式和等权平均是研究者设计的。因此，它们应称为 **human-data-derived proxy estimates**，不能称为 raw data 中直接测量的心理构念。

当前公式还存在结构性相关：

- Privacy 与 Risk 共享 nonnecessary restrictiveness。
- Convenience 与 Risk 使用方向相反的 AI trust。
- Convenience 与 Technical 共享 AI frequency。

因此，四个 trait 不应被声称为 statistically independent。研究目标应是验证 **discriminant validity**，而不是强行证明 independence。

## 5. 当前四类校准方法做了什么

现有 `raw_human_calibrated_v1` 执行以下过程：

1. 将每位参与者表示成十维可观测向量。
2. 使用 `StandardScaler` 标准化。
3. 人工指定 `KMeans(k=4)`。
4. 在 160 位训练参与者上拟合四个 cluster，并在 41 位 held-out participants 上检查稳定性。
5. 将无语义的 Cluster 0--3 与四个 hand-specified prototypes 做一对一最小距离匹配。
6. 将匹配后 cluster 内的平均 trait 作为 learned static parameters。

因此：

- participant assignment 和 cluster center 由数据决定；
- `k=4` 由研究者指定；
- archetype 名称和含义由研究者定义；
- cluster-to-name mapping 依赖 hand-specified prototypes；
- 最终参数属于 human-data-calibrated values，而不是完全自动发现的心理类型参数。

## 6. Raw data 是否支持四个自然群体

使用相同十维可观测特征，对 `k=2..8` 进行探索性比较：

| K | Silhouette | Mean seed ARI | Smallest cluster | Largest cluster |
| ---: | ---: | ---: | ---: | ---: |
| 2 | 0.196 | 1.000 | 86 | 115 |
| 3 | **0.211** | 0.988 | 22 | 100 |
| 4 | 0.198 | 0.988 | 16 | 63 |
| 5 | 0.194 | 0.927 | 17 | 58 |
| 6 | 0.194 | 0.898 | 19 | 49 |
| 7 | 0.191 | 0.787 | 14 | 48 |
| 8 | 0.189 | 0.682 | 7 | 43 |

解释：

- `k=3` 的 silhouette 略高于 `k=4`。
- 所有 silhouette 都较低，表示人群是重叠的连续偏好空间，不是边界清晰的自然类别。
- `k=4` 在随机种子间稳定，但稳定不等于四类具有强统计分离。
- 因此，raw data 不能证明存在四种独立或自然的心理 persona。

## 7. 更接近 raw-data discovery 的三类 empirical personas

如果不预先要求四个理论名称，当前特征下 `k=3` 得到：

| Empirical cluster | N | Always | Never | Ask | Necessary share | Nonnecessary share |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Persistent Sharers | 79 | 0.597 | 0.088 | 0.315 | 0.834 | 0.491 |
| Broad Deniers | 22 | 0.135 | 0.509 | 0.356 | 0.308 | 0.341 |
| Contextual Askers | 100 | 0.134 | 0.112 | 0.754 | 0.628 | 0.377 |

### Persistent Sharers

- 对必要数据的授权率最高。
- 经常选择 `Yes, always share`。
- 对非必要数据也相对宽松。

### Broad Deniers

- 超过一半的回答为 `No, never share`。
- 对必要和非必要数据的分享水平均较低。

### Contextual Askers

- 大多数回答选择两个 `ask me next time` 标签。
- 对必要数据明显比非必要数据更愿意分享。
- 很少直接永久允许或永久拒绝。

三个 cluster 的平均 self-reported privacy importance 都较高，因此 privacy importance 本身不是强区分变量。重视隐私也不必然等于总是拒绝。

## 8. 推荐的两条 persona 实验线

### A. Data-driven empirical personas

建议使用数据直接支持的描述性名称：

```text
Persistent Sharers
Broad Deniers
Contextual Askers
```

主要参数直接使用 cluster 内真人行为均值：

```text
always_share_rate
never_share_rate
ask_rate
necessary_share_score
incorrect_request_share_score
unknown_request_share_score
necessity_discrimination
initial_ai_trust
domain_sensitivity
```

这种方法减少了对抽象 trait 公式的依赖，适合作为 human-data-grounded simulator baseline。

### B. Theory-driven archetypes

继续保留：

```text
Privacy-Sensitive
Convenience-First
Technically Skilled
Risk-Averse
```

它们用于研究不同 permission decision mechanisms 和长期 RL dynamics，但必须明确：

- 四类是 researcher-defined prototypes；
- 不假设它们是独立、互斥或真实人口中的自然类型；
- 可观测静态参数可以用 human data 校准；
- 动态参数仍需要手工假设或新的 longitudinal user study。

## 9. 哪些参数能学，哪些不能学

### 当前数据可直接或近似估计

```text
initial_ai_trust
always_share_rate
never_share_rate
ask_rate
necessary_share_score
incorrect/unknown request share scores
necessity_discrimination
domain_sensitivity
```

### 只能作为研究者设计的 proxy

```text
privacy_conservatism
convenience_preference
technical_literacy
risk_aversion
```

### 当前数据不能识别

```text
minimization_preference
fatigue_sensitivity
negative_update_rate
positive_recovery_rate
trust_after_overreach
```

原因是原始调查没有 minimize 选择，也没有重复询问、agent 犯错、信任下降和恢复的纵向交互轨迹。

## 10. 当前最推荐的研究表述

> We use two complementary persona constructions. First, data-driven empirical personas summarize recurring permission-response profiles observed among 201 valid study participants. Second, theory-driven archetypes represent controlled decision mechanisms for longitudinal simulation. The former are grounded in observed response distributions, whereas the latter are researcher-defined and only partially calibrated using identifiable static signals from the human study.

中文概括：

> 我们同时使用两种互补的 persona 构造。数据驱动的 empirical personas 总结 201 位有效参与者中反复出现的权限回答模式；理论驱动的 archetypes 则用于控制长期模拟中的不同决策机制。前者直接建立在真人回答分布上，后者由研究者定义，并仅使用当前数据能够识别的静态信号进行部分校准。

## 11. 下一步

1. 将 `incorrect_explicit` 和 `unknown` 分开建模。
2. 将 `k=2..8` 比较与 bootstrap stability 写成正式脚本和固定输出。
3. 为三个 empirical personas 生成独立 config 和 QSTN persona prompts。
4. 保留四个 theory-driven archetypes 作为另一组实验条件。
5. 比较 empirical personas 与 theory-driven archetypes 对 QSTN distribution alignment 和 RL policy learning 的影响。
6. 不使用当前横截面数据声称已经学习到 fatigue、trust decay 或 recovery dynamics。
