"""Build QSTN-ready synthetic archetypes from the versioned design config."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = PROJECT_ROOT / "config" / "synthetic_archetypes.json"
DEFAULT_OUTPUT = PROJECT_ROOT / "outputs" / "synthetic_archetypes.csv"


def validate_unit_interval(values: dict[str, Any], context: str) -> None:
    for name, value in values.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{context}.{name} must be numeric, got {type(value).__name__}.")
        if not 0.0 <= float(value) <= 1.0:
            raise ValueError(f"{context}.{name} must be in [0, 1], got {value}.")


def make_policy_text(archetype: dict[str, Any]) -> str:
    policy_lines = "\n".join(
        f"- {rule}" for rule in archetype["decision_policy"]
    )
    return (
        f"Archetype: {archetype['display_name']} "
        f"({archetype['archetype_id']})\n"
        f"Core mechanism: {archetype['mechanism']}\n"
        f"Stable decision policy:\n{policy_lines}"
    )


def build_rows(config: dict[str, Any]) -> pd.DataFrame:
    expected_domains = set(config["domains"])
    archetype_ids: set[str] = set()
    rows: list[dict[str, Any]] = []

    for archetype in config["archetypes"]:
        archetype_id = str(archetype["archetype_id"])
        if archetype_id in archetype_ids:
            raise ValueError(f"Duplicate archetype_id: {archetype_id}")
        archetype_ids.add(archetype_id)

        traits = archetype["traits"]
        domain_sensitivity = archetype["domain_sensitivity"]
        validate_unit_interval(traits, f"{archetype_id}.traits")
        validate_unit_interval(domain_sensitivity, f"{archetype_id}.domain_sensitivity")
        if set(domain_sensitivity) != expected_domains:
            raise ValueError(
                f"{archetype_id} domain set does not match config domains."
            )

        persona_text = make_policy_text(archetype)
        rows.append(
            {
                "archetype_id": archetype_id,
                "persona_id": f"synthetic_{archetype_id}",
                "questionnaire_name": "permission_survey",
                "system_prompt": (
                    "You are a consistent synthetic survey respondent. Follow only the "
                    "stable decision policy supplied below. Do not invent biography or "
                    "claim to be a real participant."
                ),
                "questionnaire_instruction": (
                    "Answer each AI-agent data-sharing permission question according to the "
                    "following stable archetype. Choose exactly one listed option. Interpret "
                    "'always share' as persistent permission for similar future requests and "
                    "'ask me next time' as a context-limited decision.\n\n" + persona_text
                ),
                "persona_text": persona_text,
                "display_name": archetype["display_name"],
                "mechanism": archetype["mechanism"],
                "design_version": config["design_version"],
                "parameter_set_id": config["parameter_set_id"],
                "parameter_source": config["parameter_source"],
                "design_source": config["design_source"],
                "domain_sensitivity_json": json.dumps(
                    domain_sensitivity, ensure_ascii=False, sort_keys=True
                ),
                **{name: float(value) for name, value in traits.items()},
            }
        )

    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    with args.config.open(encoding="utf-8") as handle:
        config = json.load(handle)
    archetypes = build_rows(config)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    archetypes.to_csv(args.out, index=False, encoding="utf-8")
    print(f"Wrote {len(archetypes)} synthetic archetypes to {args.out}")


if __name__ == "__main__":
    main()
