# QSTN Setup Notes

## Existing project boundary

The parent project is a supervised four-label permission benchmark. Its existing `.venv` and `requirements.txt` remain unchanged.

## Simulator boundary

This subproject installs QSTN for questionnaire-style response generation. The first integration only validates that QSTN can access the permission dataset. It does not claim that simulated responses are human ground truth.

## Future runtime input

`OPENAI_API_KEY` is read from the process environment or a local `.env` file. The `.env` file is ignored and must never be committed.

The local `.env` also sets `OPENAI_MODEL=o4-mini`, matching the upstream repository tutorial default. This setting will be consumed by the model runner added in the next phase.

## Synthetic archetypes

The four synthetic archetypes are defined in `config/synthetic_archetypes.json` and generated separately from the 201-person calibration baseline. Their normalized traits are hand-designed hypotheses, not estimates fitted to human Task 3 labels.

## Verified installation

- Python: 3.12.3
- QSTN: 0.5.1
- Local calibration data: 16,361 permission rows from 201 participants
- Verified command: `& '.\\.venv\\Scripts\\python.exe' scripts\\check_environment.py`
- The verification script made no LLM request and sent no data externally.
